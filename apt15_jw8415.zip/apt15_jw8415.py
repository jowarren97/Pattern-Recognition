import scipy.io as sio
import numpy as np
import matplotlib.pyplot as plt
import math
import random
import time
import json
from scipy.io import loadmat
from sklearn.neighbors import NearestNeighbors
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score
from sklearn.cluster import KMeans
from sklearn.metrics import average_precision_score
from sklearn.metrics.pairwise import rbf_kernel
from sklearn.metrics.pairwise import euclidean_distances
from sklearn.neighbors import BallTree
from scipy.spatial import distance
from math import exp, expm1
import time
from metric_learn import LMNN

def AP(rank_list, true_label, n_label):
	#Function takes inputs and computes average precision
	#Done by 'plotting' precision vs recall, interpolating and calculating area under the curve
	#See https://medium.com/@jonathan_hui/map-mean-average-precision-for-object-detection-45c121a31173
	#for more details
	
	n = len(rank_list)
	precision = np.zeros(n)
	rounded_precision = np.zeros(n)
	recall = np.zeros(n)
	area = 0
	
	for i in range(n):
		TP = np.count_nonzero(rank_list[:i+1] == true_label)
		precision[i] = TP / (i+1)
		recall[i] = TP / n_label

	prev_i = 0
	for i in sorted(set(recall)):
		idx = np.where(recall == i)
		temp_precision = precision[idx]
		max_precision = max(temp_precision)
		rounded_precision[idx] = max_precision
		
		rect = (i - prev_i) * max_precision
		area = area + rect
		prev_i = i
	
	return area

def CMC(acc, rank_list, true_label, n):
	#Function takes in array of previous average accuracies (for each rank), new ranklist, label and query number
	#Computes accuracy for new ranklist
	#Updates average accuracy for each rank with 'online' method
	#Outputs new updated accuracy
	
	for i in range(len(rank_list)):
		r = rank_list[:i+1] #rank_i
		acc_r = acc[i] #accuracy for rank_i
		if np.any(r == true_label): #update accuracy for rank_i
			acc_r = (acc_r*(n-1) + 1) / n
		else:
			acc_r = acc_r*(n-1) / n
		acc[i] = acc_r
		
	#print(acc)
	return acc
	
def trainValSplit(data_labels, data_camId, training_idx, n):
	#Function takes 100 random identities and their images from training set
	#From these images, one of each label/camId placed in validation query set
	#Remaining images placed in validation gallery set
	
	val_idx = np.array([], dtype = int)
	val_query_idx = np.array([], dtype = int)
	val_gallery_idx = np.array([], dtype = int)
	randlabels = random.sample(set(data_labels[training_idx]), n)
	
	#generate random labels to select
	for r in randlabels:
		i = np.where(data_labels[training_idx] == r) #find indices of elements = r in training subset of labels
		#print("i = ", i) #indices of training subset that have label r
		val_idx = np.append(val_idx, training_idx[i])
		training_idx = np.delete(training_idx, i)
	
	val_labels = data_labels[val_idx]
	#loop through each label in validation set
	for label in set(val_labels):
		idx = np.where(val_labels == label)
		label_group_idx = val_idx[idx]
		
		idx1 = np.where(data_camId[label_group_idx] == 1)
		idx2 = np.where(data_camId[label_group_idx] == 2)
		label_group1 = label_group_idx[idx1]
		label_group2 = label_group_idx[idx2]

		#take an image from each camId for the particular label
		if label_group1.size != 0:
			val_query_idx = np.append(val_query_idx, label_group1[0])
			val_gallery_idx = np.append(val_gallery_idx, label_group1[1:])
		if label_group2.size != 0:
			val_query_idx = np.append(val_query_idx, label_group2[0])
			val_gallery_idx = np.append(val_gallery_idx, label_group2[1:])
		
	return training_idx, val_gallery_idx, val_query_idx

def kmeanBaseline(data, data_labels, data_camId, gal_idx, y_idx):
	#Function performs kmeans on input data
	#kmeans is fit to gallery, query classes are predicted using fit
	#For each query, take images in predicted class and remove any that have same camId
	#Calculate accuracy as #correct/size of reduced class
	
	n_clusters = len(set(data_labels[gal_idx]))
	accuracy = 0
	
	X = data[:,gal_idx].T
	kmeans = KMeans(n_clusters, init='k-means++').fit(X)
	gallery_cluster_labels = kmeans.labels_
	
	#loop through queries, predict, modify search results and calculate accuracy
	for i in y_idx:
		label = data_labels[i]
		camera_id = data_camId[i]

		y = data[:,i].T
		y = y.reshape(-1, 1)
		y = y.T

		y_cluster_label = kmeans.predict(y)
		idx3 = np.where(gallery_cluster_labels == y_cluster_label) #idx3 corresp to where in gallery pts in same cluster as query
		cluster_idx = gal_idx[idx3]
		
		#find which images to delete from cluster
		idx = np.where(data_labels[cluster_idx] == label) #in gallery subset of labels, find those that equal label
		idx2 = np.where(data_camId[cluster_idx[idx]] == camera_id) #in subset which have correct label, find those that have correct camid
		to_delete = np.array(idx)[0][idx2] #convert to which elements of gal_idx to delete
		cluster_idx_modified = np.delete(cluster_idx, to_delete)
		
		cluster = data_labels[cluster_idx]
		cluster_modified = data_labels[cluster_idx_modified]
		
		#calculate accuracy
		n_cluster = len(cluster_modified)
		if n_cluster != 0:
			n_correct = np.count_nonzero(cluster_modified == label)
			accuracy = accuracy + n_correct/n_cluster
	
	#compute average accuracy
	accuracy = accuracy/y_idx.shape[0]
	#print("k-mean accuracy: ", accuracy, "\n")
	return accuracy	
		
def kNN(data, data_labels, data_camId, gal_idx, y_idx, n=30):
	#Function performs kNN on gallery
	#For each query, gallery is first modified by removing images with same label/camId
	#Then, kNN search performed and n nearest neighbours found
	#Repeat for each query
	
	accuracy_sc = np.zeros((1,n))
	c = 0
	y_n = 0
	mAP = 0
	cmc_accuracy = np.zeros(n)
	
    #Remove test images with the same label + camera id as a query image
	for i in y_idx:
		y_n += 1
		label = data_labels[i]
		camera_id = data_camId[i]
		
		#get modified gallery index, specific to query
		idx = np.where(data_labels[gal_idx] == label) #in gallery subset of labels, find those that equal label
		idx2 = np.where(data_camId[gal_idx[idx]] == camera_id) #in subset which have correct label, find those that have correct camid
		to_delete = np.array(idx)[0][idx2] #convert to which elements of gallery_idx to delete

		gal_idx_modified = np.delete(gal_idx,to_delete)
				
        #Nearest Neighbour
		X = data[:,gal_idx_modified].T
		y = data[:,i].T
		y = y.reshape(-1, 1)
		y = y.T
		neigh = NearestNeighbors(n_neighbors=n)
		neigh.fit(X)
		distances, indices = neigh.kneighbors(y,n_neighbors=n,return_distance=True)
		#Checking validity with labels
		ranklist = data_labels[gal_idx_modified[indices]].flatten()
		indices = indices.flatten()
				
		if np.any(ranklist == label) == True: 
			c = c+1
		
		n_label = np.count_nonzero(labels[gal_idx_modified] == label)
		if n_label != 0:
			#calculate mAP for rank10
			mAP = mAP + AP(ranklist[:10], label, n_label)
		cmc_accuracy = CMC(cmc_accuracy, ranklist, label, y_n)
		#print(cmc_accuracy)
		
	accuracy_sc = c/y_idx.shape[0]
	mAP = mAP/y_idx.shape[0]
	
	#print(accuracy_sc)
	#plt.plot(cmc_accuracy)
	#plt.show()
	
	#print("k-NN CMC accuracy: ", cmc_accuracy)
	#print("k-NN mAP: ", mAP, "\n")
	return cmc_accuracy, mAP		

#THE FOLLOWING FUNCTIONS ARE USED BY THE ORIGINAL APPROACH
def pairwiseSubtract(A,B):
    n = A.shape[0]
    sigma = np.zeros((n,n))

    for i in range(A.shape[1]):
        for j in range(i+1,A.shape[1]):
            sub = (A[:,i]-B[:,j])
            sub = sub[:,np.newaxis]
            sigma = sigma + np.matmul(sub,sub.T)
    return sigma

def euclideanDistance(v,A):
	#Function computes Euclidean Distance between v and each column of ACCURACIES
	#Returns new array containing pairwise distances
    e = np.array([])
    for i in range(A.shape[1]):
        e = np.append(e,distance.euclidean(v, A[:,i].reshape(-1,1)))
    return e

def computeProjMatrix(data, data_labels, training_idx):
	#Function computes projection matrix 'L' and has 3 key steps:
	#1. For each pair of similar points, find impostors
	#2. For each impostor, compute weighting
	#3. Compute Sigma_S, Sigma_L
	#See http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.383.7807&rep=rep1&type=pdf
	#for more information
	
	print("Computing Projection Matrix...")
	n = data.shape[0]
	sigma_s = np.zeros((n,n))
	sigma_l = np.zeros((n,n))

	training_points = data[:,training_idx]
	training_labels = data_labels[training_idx]
	tree = BallTree(training_points.T)

	#loop through all labels
	for i in np.unique(data_labels): #For each label, we put all the data in an array
		data_label = np.empty((data.shape[0],1))  
		#collect all training imgs with same label in single array (data_label)
		for j in training_idx:
			if data_labels[j] == i:
				data_label = np.column_stack((data_label,data[:,j]))
		data_label = np.delete(data_label,0,axis=1)
		if data_label.shape[1] > 1: #We disregard labels for which there is only one image in the training set
			#And make sure we have training images for that feature
			sigma_s = sigma_s + pairwiseSubtract(data_label,data_label)
			d = np.array([])
			#For every pair within this label, are there impostors invading the perimeter?
			for u in range(data_label.shape[1]):
				x_i = data_label[:,u].reshape(-1,1)
				for v in range(u+1,data_label.shape[1]):
					x_j = data_label[:,v].reshape(-1,1)
					d = distance.euclidean(x_i,x_j) #compute distance between pair of points
					ind_neighbors = tree.query_radius(x_i.T,r=d) #find neighbours within perimeter d
					#Returns indexes in training_points of the points within this radius
					ind_neighbors = np.concatenate(ind_neighbors)
					print("looking for impostors...")
					for l in ind_neighbors:
						if training_labels[l] != i: #Detecting impostor point
							print("FOUND AN IMPOSTOR!")
							x_l = training_points[:,l].reshape(-1,1)
							#Compute multiplier for sigma_l matrix
							a = np.linalg.norm(x_i-x_l)
							b = np.linalg.norm(x_i-x_j)
							w = exp((-1)*(a/b))
							sigma_l = sigma_l + w*np.matmul((x_i-x_l),(x_i-x_l).T)

	
	eigvals, eigvecs = np.linalg.eig(sigma_s-sigma_l)
	eigvals_sorted = np.sort(eigvals)
	eigvecs_sorted = eigvecs[:, eigvals.argsort()]
	proj_matrix = eigvecs_sorted
	
	print("done!!!")              
	
	return proj_matrix
	
def	optimiseProjMatrix(data, data_labels, data_camId, proj_matrix, gal_idx, y_idx, k_min, k_max):
	#Take in full projection matrix, find optimal k
	
	print("Optimising Projection Matrix...")

	optimise = np.array([])
	for k in range(k_min, k_max):
		print(k)
		proj_k = proj_matrix[:,:k]
		projected_data = np.matmul(data.T, proj_k)
		acc, ret = kNN(projected_data.T, data_labels, data_camId, gal_idx, y_idx, 30)
		acc = acc[4] #this will select accuracy for rank 5
		optimise = np.append(optimise, acc)
		print(acc)

	k_best = np.argmax(optimise)+k_min
	print("IT'S OVER:", k_best)
	
	return k_best


#-------------------------------- LOAD & IMPORT DATA -------------------------------------	
#Import feature_data file
print("\n\nIMPORTING DATA PLEASE WAIT")
with open('feature_data.json', 'r') as f:
	features = json.load(f)
features = np.asarray(features)
features = features.T
print("Done.")

#Loading all the data
train_idx = loadmat('cuhk03_new_protocol_config_labeled.mat')['train_idx'].flatten()
camId = loadmat('cuhk03_new_protocol_config_labeled.mat')['camId'].flatten()
filelist = loadmat('cuhk03_new_protocol_config_labeled.mat')['filelist'].flatten()
gallery_idx = loadmat('cuhk03_new_protocol_config_labeled.mat')['gallery_idx'].flatten()
labels = loadmat('cuhk03_new_protocol_config_labeled.mat')['labels'].flatten()
query_idx = loadmat('cuhk03_new_protocol_config_labeled.mat')['query_idx'].flatten()

#Converting index arrays into integers for indexing features later on
train_idx = train_idx.astype(int)-1
camId = camId.astype(int)
gallery_idx = gallery_idx.astype(int)-1
labels = labels.astype(int)
query_idx = query_idx.astype(int)-1

#--------------------------------- TRAIN/VAL SPLIT ---------------------------------------
#In this section validation gallery and query sets are formed from the training data
#The validation set as a whole contains 100 identities which are completely removed from training data
#Validation query set contains an image of each identity from the 2 camera angles (therefore 200 images)
print("\n\nPERFORMING TRAIN/VAL SPLIT")
train_idx_new, val_gallery_idx, val_query_idx = trainValSplit(labels, camId, train_idx, n=100)
print("Done.")

#---------------------------------- BASELINE TESTS ---------------------------------------
#In this section the two baseline tests are performed on the test data

print("\n\nPERFORMING BASELINE TESTS")
#BASELINE APPROACH WITH K_NN
accuracy, mean_av_precision = kNN(features, labels, camId, gallery_idx, query_idx, 30)
print("Baseline kNN Results:")
print("CMC: ", accuracy)
print("mAP: ", mean_av_precision)
#BASELINE APPROACH WITH K_MEANS
accuracyk = kmeanBaseline(features, labels, camId, gallery_idx, query_idx)
print("Baseline kmeans Results:")
print("Accuracy: ", accuracyk)

#-------------------------------------- LMNN ---------------------------------------------
#In this section the process is as follows:
#1. PCA applied to feature space to reduce dimensionality (with 90% variance retained)
#2. LMNN applied to reduced feature space 

#The section is divided into 3 parts:
#1. Optimisation of LMNN w.r.t. k_neighbors
#2. Optimisation of LMNN w.r.t. regularization constant
#3. Testing of LMNN with optimal k_neighbors and reg constant
#See pypi metric learn LMNN for more info
#http://metric-learn.github.io/metric-learn/metric_learn.lmnn.html

print("\n\nPERFORMING LMNN APPROACH")
pca = PCA(svd_solver='full')
pca.fit(features[:,train_idx_new].T)
eigval = pca.explained_variance_ratio_
sum_variance = np.cumsum(eigval)
var90 = np.where(sum_variance>=0.90)[0][0]
features_pca = np.matmul(pca.components_[:var90,:],features)

#Optimise LMNN wrt k (number of neighbors considered)
print("Optimising LMNN wrt k")
k_neigh = [2,3,4,5]
accuracy = np.zeros((4,30))
accuracyk = np.zeros(4)
mean_av_precision = np.zeros(4)
i=0
for n in k_neigh:
	lmnn = LMNN(k=n)
	lmnn.fit(features_pca[:,train_idx_new].T,labels[train_idx_new]) 
	L = lmnn.transformer()
	transformed_features = np.matmul(features_pca.T,L)
	
	accuracy[i,:], mean_av_precision[i] = kNN(transformed_features.T,labels,camId,val_gallery_idx,val_query_idx,30)
	accuracyk[i] = kmeanBaseline(transformed_features.T, labels, camId, val_gallery_idx, val_query_idx)
	i = i+1

print("k: ", k_neigh)
print("mAP on validation set: ", mean_av_precision)
print("kmeans accuracy: ", accuracyk)
print("\n")


#Optimise LMNN wrt regularisation (weighting of push vs pull)
print("Optimising LMNN wrt regularisation")
reg = [0.2,0.3,0.4,0.5,0.6,0.7,0.8]
accuracy = np.zeros((7,30))
accuracyk = np.zeros(7)
mean_av_precision = np.zeros(7)
i=0
for n in reg:
	lmnn = LMNN(regularization=n)
	lmnn.fit(features_pca[:,train_idx_new].T,labels[train_idx_new]) 
	L = lmnn.transformer()
	transformed_features = np.matmul(features_pca.T,L)
	
	accuracy[i,:], mean_av_precision[i] = kNN(transformed_features.T,labels,camId,val_gallery_idx,val_query_idx,30)
	accuracyk[i] = kmeanBaseline(transformed_features.T, labels, camId, val_gallery_idx, val_query_idx)
	i = i+1

print("Regularisation: ", reg)
print("mAP on validation set: ", mean_av_precision)
print("kmeans accuracy: ", accuracyk)
print("\n")

#Perform LMNN with k=3, reg=0.5 (default)
print("Running LMNN with k=3 and reg=0.5")
lmnn = LMNN() 
print("Transforming the features...")
lmnn.fit(features_pca[:,train_idx].T,labels[train_idx]) 
L = lmnn.transformer()
transformed_features = np.matmul(features_pca.T,L)
accuracy_LMNN, mean_av_precision_LMNN = kNN(transformed_features.T,labels,camId,gallery_idx,query_idx,30)
accuracy_k_LMNN = kmeanBaseline(transformed_features.T, labels, camId, gallery_idx, query_idx)
print("LMNN kNN Results:")
print("CMC: ", accuracy_LMNN)
print("mAP: ", mean_av_precision_LMNN)
print("LMNN kmeans Results:")
print("Accuracy: ", accuracy_k_LMNN)

#---------------------------------- KERNEL LMNN ------------------------------------------
#This section investigates kernel + LMNN (KLMNN). The process is as follows:
#1. Kernelisation of feature data
#2. PCA on feature data to reduce dimensionality
#3. LMNN run on reduced kernelised feature space

#The section is divided into 2 stages
#1. Optimisation of alpha (gamma = alpha/n_features = 1/2*sigma^2)
#2. Testing with optimate gamma

print("\n\nPERFORMING KERNEL LMNN APPROACH")
#Optimise Alpha for kernel on validation set
print("Optimising KLMNN wrt alpha")
n_train = features.shape[1]
n_features = features.shape[0]
new_data = features.T
accuracy = np.zeros((4,30))
accuracyk = np.zeros(4)
mean_av_precision = np.zeros(4)
alpha = [1,3,10,30]
i=0

for g in alpha:
	start_time = time.time()
	print("Gamma = ", g)
	print("Computing kernel")
	k = np.zeros((n_train, n_train))
	k = rbf_kernel(new_data, gamma=g/n_features)
	
	print("Performing PCA")
	pca = PCA(svd_solver='full')
	pca.fit(k[:,train_idx_new].T)
	eigval = pca.explained_variance_ratio_
	sum_variance = np.cumsum(eigval)
	var90 = np.where(sum_variance>=0.90)[0][0]

	features_pca = np.matmul(pca.components_[:var90,:],k)
	
	lmnn = LMNN()
	print("Transforming the features...")
	lmnn.fit(features_pca[:,train_idx_new].T,labels[train_idx_new]) 
	L = lmnn.transformer()
	transformed_features = np.matmul(features_pca.T,L) #project data onto L
	
	accuracy[i,:], mean_av_precision[i] = kNN(transformed_features.T,labels,camId,val_gallery_idx,val_query_idx,30)
	accuracyk[i] = kmeanBaseline(transformed_features.T, labels, camId, val_gallery_idx, val_query_idx)
	i = i+1
	end_time = time.time()
	print("Time taken: ", end_time - start_time)

print("Alpha: ", alpha)
print("mAP on validation set: ", mean_av_precision)
print("kmeans accuracy: ", accuracyk)
print("\n")

#Optimal Alpha=3, perform kernel LMNN
print("Testing KLMNN, alpha=3")
n_train = features.shape[1]
n_features = features.shape[0]
new_data = features.T
k = np.zeros((n_train, n_train))
k = rbf_kernel(new_data, gamma=3/n_features)

pca = PCA(svd_solver='full')
pca.fit(k[:,train_idx_new].T)
eigval = pca.explained_variance_ratio_
sum_variance = np.cumsum(eigval)
var90 = np.where(sum_variance>=0.90)[0][0]

features_pca = np.matmul(pca.components_[:var90,:],k)
lmnn = LMNN()
lmnn.fit(features_pca[:,train_idx_new].T,labels[train_idx_new]) 
L = lmnn.transformer()
transformed_features = np.matmul(features_pca.T,L)

accuracy_KLMNN, mean_av_precision_KLMNN = kNN(transformed_features.T,labels,camId,gallery_idx,query_idx,30)
accuracy_k_KLMNN = meanBaseline(transformed_features.T, labels, camId, gallery_idx, query_idx)

print("KLMNN kNN Results:")
print("CMC: ", accuracy_KLMNN)
print("mAP: ", mean_av_precision_KLMNN)
print("KLMNN kmeans Results:")
print("Accuracy: ", accuracy_k_KLMNN)


#---------------------------------- ORIGINAL APPROACH ------------------------------------------
#This section aims to analyse the original method (see appendix of report)
#The process has two steps:
#1. PCA
#2. Finding projection matrix
#N.B the first half of the projection matrix is selected (without optimisation) as this was found
#by the source to be the best performing

#Performance was then assessed on the test set

print("\nPERFORMING ORIGINAL APPROACH")
pca = PCA(svd_solver='full')
pca.fit(k[:,train_idx_new].T)
eigval = pca.explained_variance_ratio_
sum_variance = np.cumsum(eigval)
var90 = np.where(sum_variance>=0.90)[0][0]
features_pca = np.matmul(pca.components_[:var90,:],k)
projection_matrix = computeProjMatrix(features_pca, labels, train_idx_new)
#optimiseProjMatrix(features, labels, camId, projection_matrix, val_gallery_idx, val_query_idx, 100, 200)
proj_k = projection_matrix[:,:int(var90/2)]
projected_features = np.matmul(features_pca.T, proj_k)
accuracy_original, mean_av_precision_original = kNN(projected_features.T, labels, camId, gallery_idx, query_idx, 30)
accuracy_k_original = meanBaseline(projected_features.T, labels, camId, gallery_idx, query_idx)

print("Original Approach kNN Results:")
print("CMC: ", accuracy_original)
print("mAP: ", mean_av_precision_original)
print("Original Approach kmeans Results:")
print("Accuracy: ", accuracy_k_original)

